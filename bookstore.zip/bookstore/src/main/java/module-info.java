module com.example.bookstore {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.bookstore to javafx.fxml;
    exports com.example.bookstore;
    exports com.example.bookstore.models;
    opens com.example.bookstore.models to javafx.fxml;
    exports com.example.bookstore.views;
    opens com.example.bookstore.views to javafx.fxml;
}